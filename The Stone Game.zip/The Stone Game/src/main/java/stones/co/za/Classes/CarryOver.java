package stones.co.za.Classes;

public class CarryOver {
	
	private String player;
	private int stoneLeft;
	private String message;
	private String path;
	private int cupNumber;
	
	public CarryOver() {
		super();
	}

	public CarryOver(String player, int stoneLeft, String message, String path, int cupNumber) {
		super();
		this.player = player;
		this.stoneLeft = stoneLeft;
		this.message = message;
		this.path = path;
		this.cupNumber = cupNumber;
	}

	public String getPlayer() {
		return player;
	}

	public void setPlayer(String player) {
		this.player = player;
	}

	public int getStoneLeft() {
		return stoneLeft;
	}

	public void setStoneLeft(int stoneLeft) {
		this.stoneLeft = stoneLeft;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public int getCupNumber() {
		return cupNumber;
	}

	public void setCupNumber(int cupNumber) {
		this.cupNumber = cupNumber;
	}
}
