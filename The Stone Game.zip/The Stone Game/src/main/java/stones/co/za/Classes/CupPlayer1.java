package stones.co.za.Classes;

public class CupPlayer1 {
	
	private int cup1;
	private int cup2;
	private int cup3;
	private int cup4;
	private int cup5;
	private int cup6;
	private int point;
	private String player1;
	
	public CupPlayer1() {
		super();
	}

	public CupPlayer1(int cup1, int cup2, int cup3, int cup4, int cup5, int cup6, int point, String player1) {
		super();
		this.cup1 = cup1;
		this.cup2 = cup2;
		this.cup3 = cup3;
		this.cup4 = cup4;
		this.cup5 = cup5;
		this.cup6 = cup6;
		this.point = point;
		this.player1 = player1;
	}

	public int getCup1() {
		return cup1;
	}

	public void setCup1(int cup1) {
		this.cup1 = cup1;
	}

	public int getCup2() {
		return cup2;
	}

	public void setCup2(int cup2) {
		this.cup2 = cup2;
	}

	public int getCup3() {
		return cup3;
	}

	public void setCup3(int cup3) {
		this.cup3 = cup3;
	}

	public int getCup4() {
		return cup4;
	}

	public void setCup4(int cup4) {
		this.cup4 = cup4;
	}

	public int getCup5() {
		return cup5;
	}

	public void setCup5(int cup5) {
		this.cup5 = cup5;
	}

	public int getCup6() {
		return cup6;
	}

	public void setCup6(int cup6) {
		this.cup6 = cup6;
	}

	public int getPoint() {
		return point;
	}

	public void setPoint(int point) {
		this.point = point;
	}

	public String getPlayer1() {
		return player1;
	}

	public void setPlayer1(String player1) {
		this.player1 = player1;
	}

}
