package stones.co.za.Servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import stones.co.za.Classes.Calculations;
import stones.co.za.Classes.Player;

/**
 * Servlet implementation class RecordServelt
 */
@WebServlet("/RecordServelt.do")
public class RecordServelt extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String tittle = request.getParameter("tittle");
		String name = request.getParameter("name");
		String surname = request.getParameter("surname");
		
		Player player1= Calculations.AddPlayer(tittle,name,surname);
		
		HttpSession session = request.getSession();
		session.setAttribute("player1", player1);
		
		String url = "/Player_Info.jsp";
        RequestDispatcher dispatcher = request.getRequestDispatcher(url);
        dispatcher.forward(request, response);
	}

}
