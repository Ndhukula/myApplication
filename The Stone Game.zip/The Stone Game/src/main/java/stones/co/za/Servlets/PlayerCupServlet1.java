package stones.co.za.Servlets;

import java.io.IOException;

import javax.servlet.DispatcherType;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import stones.co.za.Classes.BothPlayers;
import stones.co.za.Classes.Calculations;
import stones.co.za.Classes.CarryOver;
import stones.co.za.Classes.CollectionOfAll;
import stones.co.za.Classes.CupPlayer1;

/**
 * Servlet implementation class PlayerCupServlet1
 */
@WebServlet("/PlayerCupServlet1.do")
public class PlayerCupServlet1 extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
			String name = request.getParameter("cupNumber");
			int cupNumber = Integer.parseInt(name);
			
			HttpSession session = request.getSession();
			
			//CarryOver carryOver = (CarryOver) session.getAttribute("carryOver");
			//BothPlayers bothPlayer = (BothPlayers) session.getAttribute("bothPlayers");
			
			CollectionOfAll all = (CollectionOfAll) session.getAttribute("collectionOfAll");
			CollectionOfAll collectionOfAll = Calculations.playGaming(all,cupNumber);
			
			//BothPlayers bothPlayers = Calculations.playGame(bothPlayer,cupNumber,carryOver);
			//session.setAttribute("bothPlayers", bothPlayers);
			session.setAttribute("collectionOfAll", collectionOfAll);
			
			CarryOver carryOver = collectionOfAll.getCarryOver();
	
			String url = "/Result_PlayerSame1.jsp";
			RequestDispatcher dispatcher = request.getRequestDispatcher(url);
			dispatcher.forward(request, response);
	}

}
