package stones.co.za.Classes;

public class CollectionOfAll {
	
	private BothPlayers bothPlayers;
	private CarryOver carryOver;
		
	public CollectionOfAll() {
		super();
	}

	public CollectionOfAll(BothPlayers bothPlayers, CarryOver carryOver) {
		super();
		this.bothPlayers = bothPlayers;
		this.carryOver = carryOver;
	}

	public BothPlayers getBothPlayers() {
		return bothPlayers;
	}

	public void setBothPlayers(BothPlayers bothPlayers) {
		this.bothPlayers = bothPlayers;
	}

	public CarryOver getCarryOver() {
		return carryOver;
	}

	public void setCarryOver(CarryOver carryOver) {
		this.carryOver = carryOver;
	}
	
	
	
	

}
