package stones.co.za.Classes;

import java.util.ArrayList;


public class Calculations {
	CarryOver carryOver = null;

	public static Player AddPlayer(String tittle, String name, String surname) {
		
		Player player = new Player(tittle, name, surname);
		return player;
	}
	
	public static BothPlayers setPlayers(CupPlayer1 cupPlayer1, CupPlayer2 cupPlayer2) {
		
		cupPlayer1 = new CupPlayer1(6, 6, 6, 6, 6, 6, 0, "player1");
		cupPlayer2 = new CupPlayer2(6, 6, 6, 6, 6, 6, 0, "player2");
		
		BothPlayers bothPlayers = new BothPlayers(cupPlayer1, cupPlayer2);
		return bothPlayers;
	}

	public static CarryOver playerReminder(String player, int stonesLeft, String message,String path, int cupNumber) {
		
		CarryOver carryOver = new CarryOver(player, stonesLeft, message,path, cupNumber);
		return carryOver;
	}
	
	public static CollectionOfAll AddAll(BothPlayers bothPlayers, CarryOver carryOver2) {
		
		CollectionOfAll collectionOfAll = new CollectionOfAll(bothPlayers, carryOver2);
		return collectionOfAll;
	}


	public static CollectionOfAll playGaming(CollectionOfAll all, int cupNumber) {
		
		BothPlayers bothPlayer = all.getBothPlayers();
		CarryOver carryOver = all.getCarryOver();
		
		String player = carryOver.getPlayer();
		int stoneLeft = carryOver.getStoneLeft();
		CupPlayer1 cupPlayer1 = bothPlayer.getCupPlayer1();
		CupPlayer2 cupPlayer2 = bothPlayer.getCupPlayer2();
		
		//player1 currect stones in the cup
				int player1cup1 = cupPlayer1.getCup1();
				int player1cup2 = cupPlayer1.getCup2();
				int player1cup3 = cupPlayer1.getCup3();
				int player1cup4 = cupPlayer1.getCup4();
				int player1cup5 = cupPlayer1.getCup5();
				int player1cup6 = cupPlayer1.getCup6();
				int player1point = cupPlayer1.getPoint();
				
				int[] player1Stones = {player1cup1,player1cup2,player1cup3,player1cup4,player1cup5,player1cup6,player1point};
				
				//player 2 currect stones in the cup
				int player2cup1 = cupPlayer2.getCup1();
				int player2cup2 = cupPlayer2.getCup2();
				int player2cup3 = cupPlayer2.getCup3();
				int player2cup4 = cupPlayer2.getCup4();
				int player2cup5 = cupPlayer2.getCup5();
				int player2cup6 = cupPlayer2.getCup6();
				int player2point = cupPlayer2.getPoint();
				
				int[] player2Stones = {player2cup1,player2cup2,player2cup3,player2cup4,player2cup5,player2cup6,player2point};
				
				cupNumber = cupNumber -1;
				
				if(stoneLeft == 0) {
					if(player.equals("player1")) {
							
						if(cupNumber == 0) {
							
							stoneLeft= player1Stones[cupNumber];
								for(int y = 0; y < player1Stones.length; y++) {
									
									player1Stones[y] = player1Stones[y] +1;
									stoneLeft = stoneLeft -1;
									
								}
								player1Stones[cupNumber] = 0;
								
						}else if(cupNumber == 1) {
							
							stoneLeft= player1Stones[cupNumber];
								for(int y = 0; y < player1Stones.length; y++) {
									
									player1Stones[y] = player1Stones[y] +1;
									stoneLeft = stoneLeft -1;
									
								}
								player1Stones[cupNumber] = 0;
								player1Stones[0] = player1cup1;
						}else if(cupNumber == 2) {
							
							stoneLeft= player1Stones[cupNumber];
								for(int y = 0; y < player1Stones.length; y++) {
									
									player1Stones[y] = player1Stones[y] +1;
									stoneLeft = stoneLeft -1;
									
								}
								player1Stones[cupNumber] = 0;
								player1Stones[0] = player1cup1;
								player1Stones[1] = player1cup2;
						}else if(cupNumber == 3) {
							
							stoneLeft= player1Stones[cupNumber];
								for(int y = 0; y < player1Stones.length; y++) {
									
									player1Stones[y] = player1Stones[y] +1;
									stoneLeft = stoneLeft -1;
									
								}
								player1Stones[cupNumber] = 0;
								player1Stones[0] = player1cup1;
								player1Stones[1] = player1cup2;
								player1Stones[2] = player1cup3;
								
						}else if(cupNumber == 4) {
							
							stoneLeft= player1Stones[cupNumber];
								for(int y = 0; y < player1Stones.length; y++) {
									
									player1Stones[y] = player1Stones[y] +1;
									stoneLeft = stoneLeft -1;
									
								}
								player1Stones[cupNumber] = 0;
								player1Stones[0] = player1cup1;
								player1Stones[1] = player1cup2;
								player1Stones[2] = player1cup3;
								player1Stones[3] = player1cup4;
								
						}else if(cupNumber == 5) {
							
							stoneLeft= player1Stones[cupNumber];
								for(int y = 0; y < player1Stones.length; y++) {
									
									player1Stones[y] = player1Stones[y] +1;
									stoneLeft = stoneLeft -1;
									
								}
								player1Stones[cupNumber] = 0;
								player1Stones[0] = player1cup1;
								player1Stones[1] = player1cup2;
								player1Stones[2] = player1cup3;
								player1Stones[3] = player1cup4;
								player1Stones[4] = player1cup5;
								
						}else if(cupNumber == 6) {
							
							stoneLeft= player1Stones[cupNumber];
								for(int y = 0; y < player1Stones.length; y++) {
									
									player1Stones[y] = player1Stones[y] +1;
									stoneLeft = stoneLeft -1;
									
								}
								player1Stones[cupNumber] = 0;
								player1Stones[0] = player1cup1;
								player1Stones[1] = player1cup2;
								player1Stones[2] = player1cup3;
								player1Stones[3] = player1cup4;
								player1Stones[4] = player1cup5;
						}
						
						player1cup1 = player1Stones[0];
						player1cup2 = player1Stones[1];
						player1cup3 = player1Stones[2];
						player1cup4 = player1Stones[3];
						player1cup5 = player1Stones[4];
						player1cup6 = player1Stones[5];
						player1point = player1Stones[6];	
						
						cupPlayer1 = new CupPlayer1(player1cup1, player1cup2, player1cup3, player1cup4, player1cup5, player1cup6, player1point, player);
						
						bothPlayer = new BothPlayers(cupPlayer1, cupPlayer2);
						
						all = new CollectionOfAll(bothPlayer, carryOver);
						
						int count = carryOver.getCupNumber();
						int turns = 0;
						
						if(stoneLeft > 0) {
							int totalPLayer = 6;
							int max = totalPLayer - stoneLeft;
							
							for(int x = 0; x < max; x++) {
								count = count +1;
								
								player2Stones[x] = player2Stones[x] +1;
								
							}
							player2cup1 = player2Stones[0];
							player2cup2 = player2Stones[1];
							player2cup3 = player2Stones[2];
							player2cup4 = player2Stones[3];
							player2cup5 = player2Stones[4];
							player2cup6 = player2Stones[5];
							player2point = cupPlayer2.getPoint();
							
							carryOver.setCupNumber(cupNumber);
							carryOver.setMessage("Player 1 keep playing from cup number of second player "+count);
							carryOver.setPath("/Result_PlayerSame1.jsp");
						
							cupPlayer2 = new CupPlayer2(player2cup1, player2cup2, player2cup3, player2cup4, player2cup5, player2cup6, player2point, player);
							bothPlayer = new BothPlayers(cupPlayer1, cupPlayer2);
							all = new CollectionOfAll(bothPlayer, carryOver);
						}
						
						
						
					}else if(player.equals("player2")) {
						
					}
					
				}else if(stoneLeft >0) {
					if(player.equals("player1")) {
						
						
					}else if(player.equals("player2")) {
						
					}
					
				}
		
		
		
		
		
		return all;
		
	}

	



}
