package stones.co.za.Servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import stones.co.za.Classes.BothPlayers;
import stones.co.za.Classes.Calculations;
import stones.co.za.Classes.CarryOver;
import stones.co.za.Classes.CollectionOfAll;
import stones.co.za.Classes.CupPlayer1;
import stones.co.za.Classes.CupPlayer2;

/**
 * Servlet implementation class StarGameServlet
 */
@WebServlet("/StarGameServlet.do")
public class StarGameServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String player = "player1";
		int stonesLeft = 0;
		String message = "";
		String path = "";
		int cupNumber = 0;
		
		CupPlayer1 cupPlayer1 = null;
		CupPlayer2 cupPlayer2 = null;
		
		BothPlayers bothPlayers = Calculations.setPlayers(cupPlayer1,cupPlayer2);
		CarryOver carryOver =Calculations.playerReminder(player, stonesLeft,message, path,cupNumber);
		CollectionOfAll collectionOfAll = Calculations.AddAll(bothPlayers,carryOver);
		
		
		HttpSession session = request.getSession();
		//session.setAttribute("bothPlayers", bothPlayers);
		//session.setAttribute("carryOver", carryOver);
		session.setAttribute("collectionOfAll", collectionOfAll);
		
		String url = "/Result_Page.jsp";

		RequestDispatcher dispatcher = request.getRequestDispatcher(url);
		dispatcher.forward(request, response);
		
		
	}

}
