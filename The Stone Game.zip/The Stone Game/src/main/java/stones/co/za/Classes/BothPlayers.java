package stones.co.za.Classes;

public class BothPlayers {
	
	private CupPlayer1 cupPlayer1;
	private CupPlayer2 cupPlayer2;
	
	public BothPlayers() {
		super();
	}

	public BothPlayers(CupPlayer1 cupPlayer1, CupPlayer2 cupPlayer2) {
		super();
		this.cupPlayer1 = cupPlayer1;
		this.cupPlayer2 = cupPlayer2;
	}

	public CupPlayer1 getCupPlayer1() {
		return cupPlayer1;
	}

	public void setCupPlayer1(CupPlayer1 cupPlayer1) {
		this.cupPlayer1 = cupPlayer1;
	}

	public CupPlayer2 getCupPlayer2() {
		return cupPlayer2;
	}

	public void setCupPlayer2(CupPlayer2 cupPlayer2) {
		this.cupPlayer2 = cupPlayer2;
	}

}
